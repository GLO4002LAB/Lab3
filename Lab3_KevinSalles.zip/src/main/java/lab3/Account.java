package lab3;

public interface Account {
	
	public void withDraw(double amount);
	
	public void addAmount(double amount);
}

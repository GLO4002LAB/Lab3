package lab3;

public interface CashDispenser {
	public void giveMoney(double money);
}

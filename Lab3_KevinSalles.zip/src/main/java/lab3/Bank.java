package lab3;

public interface Bank {
	public Account findAccountByNumber(int accountNumber);
}
